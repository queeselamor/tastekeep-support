## TasteKeep: Recipe Keeper

**Your recipes, in one private book, for life. No account, no subscription.**

TasteKeep is a private recipe book for iPhone, iPad and iPhone Duo. You keep family recipes with photos and steps, add a recipe from a link or a note, cook with timers that stay on the Lock Screen, plan the week and turn the plan into a shopping list sorted by aisle. It speaks 35 languages, and the import reads recipe sites and notes in each of them. There is no account and no tracking, and Pro is a one-time purchase.

### At a glance
- **Platforms:** iPhone and iPad. iPhone Duo layouts for the closed, book, laptop and open poses since 1.2.1 (14 October 2026).
- **Price:** Free. TasteKeep Pro is a one-time $9.99 (regional pricing), no subscription.
- **Languages:** 35 in the app since 1.3.3 (4 November 2026), from Swedish to Thai, each with its own grocery dictionary and import rules for local units. The App Store lists 34, because it shows Brazilian and European Portuguese as one. The App Store page is translated for 39 locales.
- **Privacy:** no account and no ads. The App Store label reads "Data Not Collected". Recipes sync through your own iCloud.
- **Developer:** Uladzislau Vyskvarka, solo developer.
- **App Store:** https://apps.apple.com/app/apple-store/id6805066789?pt=129091971&ct=press-kit&mt=8
- **Public beta (TestFlight):** https://testflight.apple.com/join/NPdfy1F3
- **Support and privacy policy:** https://queeselamor.github.io/tastekeep-support/
- **Press page:** https://queeselamor.github.io/tastekeep-support/press/
- **Press contact:** uladzislau.vyskvarka@gmail.com

### In the press
- AppleWorldHellas (Greece, in Greek), 5 November 2026: https://appleworldhellas.com/tastekeep-iphone-ipad-recipes-greek/

### What TasteKeep does
**Keep.** You save a recipe with photos, ingredients, step-by-step instructions, cooking time, servings, tags and the source. Ingredients can sit in groups, like "For the crust" and "For the filling". Paste a link to a recipe page or the text of a note, and TasteKeep fills in the title, photo, ingredients and steps; from Safari, tap Share and choose TasteKeep. You search and filter by meal, dish type or tag, mark favorites and open recent recipes in a tap.

**Cook.** Cooking mode shows one step at a time in large type, with an optional photo per step and a timer built into the step. The timer keeps running on the Lock Screen and in the Dynamic Island, so the phone can stay locked while your hands are busy. On iOS 26 or later it rings like an alarm, even on silent. Finish cooking, and the recipe page counts how many times you've made it.

**Plan (Pro).** The weekly planner comes with week templates. You add recipes to breakfast, lunch and dinner, reuse a favorite week and turn the plan into a shopping list. The Today's Meals widget shows what to cook now and the rest of the day, and a Sunday reminder asks you to plan the week.

**Shop (Pro).** TasteKeep builds shopping lists from recipes and plans, groups them by store aisle and adds up quantities. You can keep several lists at once, one per store, and share them. In the Shopping List widget you check off items on the Home Screen, and a Control Center button opens the list.

**Yours.** Recipes live on your device and in your own iCloud. There is no sign-up and no ad. You choose when to back up and what to share.

### What's new in 1.3.4 (5 November 2026)
- Ingredient groups, free: a pie keeps "For the crust" and "For the filling" apart
- Groups show in the recipe and stay in shared images and PDFs
- Import picks up groups from websites and notes
- On recipe sites, import skips ads and tips and finds the right ingredients and steps

### What's new in 1.3.3 (4 November 2026)
- TasteKeep in 35 languages, from Swedish to Thai, with 18 new ones including Greek, Finnish, Hebrew and Vietnamese
- Import reads recipe sites and notes in each language, with local units like "κ.σ." in Greek or "spsk" in Danish
- Imported recipes add up their times: "Prep 15 min" and "Roast 40 min" make 55 minutes
- The shopping list puts more products in the right aisle

### What's new in 1.3.1 and 1.3.2 (23 and 27 October 2026)
- Paste a link into Import with one tap, without the extra question about pasting
- Import a recipe, and steps like "Bake for 45 minutes" come with their timer set
- On iPad and on an open iPhone Duo, the shopping list fills the screen in two columns

### What's new in 1.3 (22 October 2026)
- Home Screen widgets (Pro): Today's Meals shows what to cook now, and in Shopping List you check off items in the widget itself
- A Control Center button opens the shopping list
- Step timers ring like an alarm, even on silent (iOS 26 or later)
- Touch and hold a recipe card to add it to the plan or share it
- The recipe page counts how many times you've cooked it

### Earlier
- 1.2.3 (15 October 2026): shopping lists sort every item into its aisle in every app language (17 at the time); fixes for iCloud sync and import
- 1.2.1 (14 October 2026): made for iPhone Duo, the layout follows the pose
- 1.2 (10 October 2026): add a recipe from a link or a note; Share to TasteKeep from Safari; share a recipe as images, a PDF or text
- 1.1 (30 September 2026): weekly meal planner and shopping lists (Pro), cooking timers on the Lock Screen, full iPad layout

### Why it exists
Most recipe apps come with a subscription and a feed of other people's recipes. TasteKeep keeps your own recipes in your own book on your own devices, adds a planner and a shopping list when you need them, and charges one price for life.

### About the developer
Uladzislau Vyskvarka designs and builds TasteKeep alone. It started as a private family recipe book and grew into a planner and shopping companion.

### Assets
- App icon (PNG, 1024×1024)
- iPhone screenshots (12) and iPad screenshots (11) in Apple device frames, in English, from TasteKeep 1.3.4: the recipe book, import from a link, cooking mode with a timer, Home Screen widgets, Share to TasteKeep, the planner, the shopping list by aisle, a recipe, ingredient groups (iPhone), filters, Home and settings
- iPhone Duo App Store screenshots (10): closed, open portrait and open landscape
- You may use the screenshots in coverage of TasteKeep. Reviewers can request a free TasteKeep Pro code.

### Quick facts for editors
- Founded: 2026, solo developer
- Releases: TasteKeep 1.0, September 2026; 1.1 with the planner and iPad, 30 September 2026; 1.2 with import from a link or a note and Share to TasteKeep, 10 October 2026; 1.2.1 with iPhone Duo layouts, 14 October 2026; 1.3 with Home Screen widgets and alarm timers, 22 October 2026; 1.3.3 in 35 languages, 4 November 2026; 1.3.4 with ingredient groups, 5 November 2026
- Business model: free app with a one-time Pro purchase; enrolled in Apple's Small Business Program
- Built with Flutter and native iOS extensions (Live Activities and AlarmKit for timers, WidgetKit for widgets, the Share extension for import)
